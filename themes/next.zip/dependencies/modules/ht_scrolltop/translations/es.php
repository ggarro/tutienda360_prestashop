<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ht_scrolltop}prestashop>ht_scrolltop_f4cd08df433d3254e501b83db6df2994'] = ' Hiddentechies Desplazarse hacia arriba';
$_MODULE['<{ht_scrolltop}prestashop>ht_scrolltop_f369a421df2ed206456a27c2e20150f9'] = 'Este módulo permite al visitante desplazarse fácilmente hacia la parte superior de la página, con opciones e imagen totalmente personalizables.';
$_MODULE['<{ht_scrolltop}prestashop>ht_scrolltop_876f23178c29dc2552c0b48bf23cd9bd'] = 'Este módulo permite al visitante desplazarse fácilmente hacia la parte superior de la página, con opciones e imagen totalmente personalizables.';
$_MODULE['<{ht_scrolltop}prestashop>ht_scrolltop_fe5d926454b6a8144efce13a44d019ba'] = 'Valor de configuración no válido';
$_MODULE['<{ht_scrolltop}prestashop>ht_scrolltop_c888438d14855d7d96a2724ee9c306bd'] = 'Ajustes actualizan';
$_MODULE['<{ht_scrolltop}prestashop>ht_scrolltop_f4f70727dc34561dfde1a3c529b6205c'] = 'Ajustes';
$_MODULE['<{ht_scrolltop}prestashop>ht_scrolltop_1d104569c9c9be26791eccee268caa46'] = 'Valor de texto';
$_MODULE['<{ht_scrolltop}prestashop>ht_scrolltop_56ebe40ba9132fa12e29786bb4000e4e'] = 'Valor del icono';
$_MODULE['<{ht_scrolltop}prestashop>ht_scrolltop_8110d4fe243952ae5c531ea0c551f7ad'] = 'Utilice la clase de icono Fontawesome. es decir, fa-chevron-up';
$_MODULE['<{ht_scrolltop}prestashop>ht_scrolltop_5b4f18f0df1673e2af9b0933fb9afd75'] = 'Color del texto / icono';
$_MODULE['<{ht_scrolltop}prestashop>ht_scrolltop_095ef73b1635ff7242f4b4b6da3905fe'] = 'es decir, #ffffff';
$_MODULE['<{ht_scrolltop}prestashop>ht_scrolltop_6125b0037efd7f80a287a579358822f5'] = 'Color de desplazamiento del texto / icono';
$_MODULE['<{ht_scrolltop}prestashop>ht_scrolltop_75e7422f2fe253fc69d3f6c148d197ee'] = 'Color de fondo';
$_MODULE['<{ht_scrolltop}prestashop>ht_scrolltop_a06008a8a5e0275f7f9281bf2dcd1209'] = 'es decir, # 333333';
$_MODULE['<{ht_scrolltop}prestashop>ht_scrolltop_a15bcab75394e8c3abe5bfd9658bbad5'] = 'Color de fondo al pasar el mouse';
$_MODULE['<{ht_scrolltop}prestashop>ht_scrolltop_3fde817162b2094598d19c26fc4f7832'] = 'es decir, # 666666';
$_MODULE['<{ht_scrolltop}prestashop>ht_scrolltop_475c80ecff56299d3527cf51af68e48c'] = 'Color del borde';
$_MODULE['<{ht_scrolltop}prestashop>ht_scrolltop_596c4341c229a7896bfa87770b6b7363'] = 'Color de desplazamiento del borde';
$_MODULE['<{ht_scrolltop}prestashop>ht_scrolltop_aa51285376719885f6cbfb240ba8faf2'] = 'Tamano del texto';
$_MODULE['<{ht_scrolltop}prestashop>ht_scrolltop_f27ce3ca8f1827839641490b4a688996'] = 'es decir, 13px';
$_MODULE['<{ht_scrolltop}prestashop>ht_scrolltop_c9cc8cce247e49bae79f15173ce97354'] = 'Salvar';
$_MODULE['<{ht_scrolltop}prestashop>ht_scrolltop_630f6dc397fe74e52d5189e2c80f282b'] = 'Volver a la lista';
