<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ht_googleanalytics}prestashop>ht_googleanalytics_5e42e8236bec7d2ee0790312e1aa9b42'] = 'Hiddentechies Google Analytics';
$_MODULE['<{ht_googleanalytics}prestashop>ht_googleanalytics_8e00c32e12b2754d4b546bbd7d4b334f'] = 'Este módulo le permite realizar un seguimiento de su sitio utilizando el último código de seguimiento de Google Analytics.';
$_MODULE['<{ht_googleanalytics}prestashop>ht_googleanalytics_876f23178c29dc2552c0b48bf23cd9bd'] = '¿Estas seguro que lo quieres desinstalar?';
$_MODULE['<{ht_googleanalytics}prestashop>ht_googleanalytics_fe5d926454b6a8144efce13a44d019ba'] = 'Valor de configuración no válido';
$_MODULE['<{ht_googleanalytics}prestashop>ht_googleanalytics_c888438d14855d7d96a2724ee9c306bd'] = 'Ajustes actualizan';
$_MODULE['<{ht_googleanalytics}prestashop>ht_googleanalytics_f4f70727dc34561dfde1a3c529b6205c'] = 'Ajustes';
$_MODULE['<{ht_googleanalytics}prestashop>ht_googleanalytics_a4f04afed956384eb3be07a0c6afb5fd'] = 'ID de seguimiento de Google';
$_MODULE['<{ht_googleanalytics}prestashop>ht_googleanalytics_c9cc8cce247e49bae79f15173ce97354'] = 'Salvar';
$_MODULE['<{ht_googleanalytics}prestashop>ht_googleanalytics_630f6dc397fe74e52d5189e2c80f282b'] = 'Volver a la lista';
